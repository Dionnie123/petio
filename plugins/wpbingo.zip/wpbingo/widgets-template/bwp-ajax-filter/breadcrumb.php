<?php
	set_query_var('paged', false);
	petio_woocommerce_breadcrumb();
?>